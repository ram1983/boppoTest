package in.nit.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import in.nit.model.Product;
import in.nit.service.IProductService;

@Controller
public class ProductController {
	@Autowired
	private IProductService service;

	// 1. Display Product add page
	@RequestMapping("/prodOprs1")
	public String showOperation1() {
		return "ProductOperations";
	}

	// 2. Display Product modify page
	@RequestMapping("/allprod")
	public String getAllProduct(Model model) {
		// read data from DB
		List<Product> list = service.getAllProducts();
		// send data to UI
		model.addAttribute("list", list);
		return "ProductData";
	}

	// 3. Display Product add page
	@RequestMapping("/aprod")
	public String showProductPage() {
		return "addProductDetails";
	}

	// 2. Read Form data as ModelAttribute and save
	@RequestMapping(value = "/addProd", method = RequestMethod.POST)
	public String saveData(@ModelAttribute Product product, Model model) {
		// save data in DB
		Integer id = service.saveProduct(product);
		// create message
		String msg = "Product Add Successfully";
		// send to UI
		model.addAttribute("message", msg);
		// Goto UI Page back
		return "addProductDetails";
	}

	// 4. Delete row by Id .../delete?pid=10
	@RequestMapping("/delete")
	public String deleteOne(@RequestParam("pid") Integer id, Model model) {
		service.deleteProduct(id);
		model.addAttribute("message", "Product '" + id + "' Deleted");
		// send remaining data
		// read data from DB
		List<Product> list = service.getAllProducts();
		// send data to UI
		model.addAttribute("list", list);
		return "ProductData";
	}

	// 5. show edit page with data
	@RequestMapping("/edit")
	public String showEdit(@RequestParam("pid") Integer id, Model model) {
		Product p = service.getOneProduct(id);
		// send data to UI and fill in HTML FORM
		model.addAttribute("ob", p);
		return "ProductEdit";
	}

	// 6. Update Product
	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public String updateOne(@ModelAttribute Product product, Model model) {
		service.updateProduct(product);
		// send data to UI
		model.addAttribute("message", "Product " + product.getProdId() + "Updated");
		// send othre data
		List<Product> list = service.getAllProducts();
		model.addAttribute("list", list);
		return "ProductData";
	}

	// 7. Get All Products to UI
	// all?page=4
	@RequestMapping("/all")
	public String showAll(@PageableDefault(size = 3) Pageable pageable, Model model) {
		Page<Product> page = service.getAllProducts(pageable);
		model.addAttribute("list", page.getContent());
		model.addAttribute("page", page);
		return "ProductData";
	}

	// 8. Display ProductSearching page
	@RequestMapping("/prodLike")
	public String showProdLike() {
		return "SearchingProductPage";
	}

	// 9. Get Autocomplete Products to UI
	// all?page=4
	@RequestMapping("/autocomplete")
	public String showFilter(@RequestParam("prodName") String prodName, Model model) {
		List<Product> list = service.getAllProductsByName(prodName);
		model.addAttribute("list", list);
		return "SearchingProductResult";
	}

}
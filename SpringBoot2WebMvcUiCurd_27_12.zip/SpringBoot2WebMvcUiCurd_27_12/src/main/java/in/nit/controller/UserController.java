package in.nit.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import in.nit.model.User;
import in.nit.service.IUserService;

@Controller
public class UserController {

	private static final Logger logger = LoggerFactory.getLogger(UserController.class);

	@Autowired
	private IUserService userService;

	// 1. Display Landing page
	@RequestMapping("/landing")
	public String landingPage() {
		return "Landing";
	}

	// 2. Display Register page
	@RequestMapping("/register")
	public String showRegisterPage() {
		return "UserRegister";
	}

	// 3. Read Form data as ModelAttribute and save
	@RequestMapping(value = "/saveUser", method = RequestMethod.POST)
	public String saveUser(@ModelAttribute User user, Model model) {
		logger.debug(user.getfName() + " " + user.getlName() + " " + user.getEmail() + " " + user.getPassword());
		System.out.println(user.getfName() + " " + user.getlName() + " " + user.getEmail() + " " + user.getPassword());

		// check user exists
		User u = userService.findByEmail(user);
		if ((u != null) && (u.getEmail().trim().equalsIgnoreCase(user.getEmail().trim()))) {
			String msg = "Email Already Registered/Please Register on Differenet Email";
			model.addAttribute("message", msg);
		} else {
			// save data in DB
			userService.saveUser(user);
			// create message
			String msg = "User  Registered";
			// send to UI
			model.addAttribute("message", msg);

		}
		// Goto UI Page back
		return "UserRegister";
	}

	// 4. Display Login page
	@RequestMapping("/login")
	public String logInPage() {
		return "Login";
	}

	// 5. show edit page with data
	@RequestMapping(value = "/getLogin", method = RequestMethod.POST)
	public String showEdit(@ModelAttribute User user, Model model) {
		User u = userService.getOneUser(user);
		// send data to UI and fill in HTML FORM
		if (u != null) {
			model.addAttribute("ob", u);
			return "ProductOperations";
		} else {
			// create message
			String msg = "Invalid UserName/Password";
			// send to UI
			model.addAttribute("message", msg);
			// Goto UI Page back
		}
		return "Login";
	}

}

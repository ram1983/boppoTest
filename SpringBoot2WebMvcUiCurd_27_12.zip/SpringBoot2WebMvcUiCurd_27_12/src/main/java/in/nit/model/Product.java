package in.nit.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Product implements Comparable<Product> {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer prodId;

	private String prodCode;
	private String prodName;
	private String prodCost;
	private Integer quantity;

	public Product() {
		super();
	}

	public Product(Integer prodId, String prodCode, String prodName, String prodCost, Integer quantity) {
		super();
		this.prodId = prodId;
		this.prodCode = prodCode;
		this.prodName = prodName;
		this.prodCost = prodCost;
		this.quantity = quantity;
	}

	public Integer getProdId() {
		return prodId;
	}

	public void setProdId(Integer prodId) {
		this.prodId = prodId;
	}

	public String getProdCode() {
		return prodCode;
	}

	public void setProdCode(String prodCode) {
		this.prodCode = prodCode;
	}

	public String getProdName() {
		return prodName;
	}

	public void setProdName(String prodName) {
		this.prodName = prodName;
	}

	public String getProdCost() {
		return prodCost;
	}

	public void setProdCost(String prodCost) {
		this.prodCost = prodCost;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "Product [prodId=" + prodId + ", prodCode=" + prodCode + ", prodName=" + prodName + ", prodCost="
				+ prodCost + ", quantity=" + quantity + "]";
	}

	public int compareTo(Product p) {
		if (prodId == p.prodId)
			return 0;
		else if (prodId > p.prodId)
			return 1;
		else
			return -1;
	}

}

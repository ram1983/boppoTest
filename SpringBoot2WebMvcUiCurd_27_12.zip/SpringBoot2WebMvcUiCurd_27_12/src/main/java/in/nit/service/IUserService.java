package in.nit.service;

import in.nit.model.User;

public interface IUserService {

		// save product
		public void saveUser(User user);
		// fetch one product
		public User getOneUser(User user);
		//is record exist by given id
		public boolean isExist(Integer id);
		
		public User findByEmail(User user);
}

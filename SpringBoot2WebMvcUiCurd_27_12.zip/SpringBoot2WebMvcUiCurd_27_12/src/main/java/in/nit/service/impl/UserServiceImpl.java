package in.nit.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.nit.model.User;
import in.nit.repo.UserRepository;
import in.nit.service.IUserService;

@Service
public class UserServiceImpl implements IUserService {

	@Autowired
	private UserRepository repo;
	
	
	@Override
	public void saveUser(User user) {
		repo.save(user);
	}

	@Override
	public User getOneUser(User user) {
		User temp=repo.findByEmailAndPassword(user.getEmail(),user.getPassword());
		return temp;
	}

	@Override
	public boolean isExist(Integer id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public User findByEmail(User user) {
		User temp=repo.findByEmail(user.getEmail());
		return temp;
	}

}
